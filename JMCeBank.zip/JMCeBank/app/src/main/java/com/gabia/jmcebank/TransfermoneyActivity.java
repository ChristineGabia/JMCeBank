package com.gabia.jmcebank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TransfermoneyActivity extends AppCompatActivity {
    EditText txtnumber, txtamount;
    Button btnsend, btnback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfermoney);

        txtamount = findViewById(R.id.ET_AmountUpdate);
        txtnumber = findViewById(R.id.ET_UserPhone);
        btnsend = findViewById(R.id.btnSend);
        btnback = findViewById(R.id.btnBack);

        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String amountsend = txtamount.getText().toString().trim();
                String usernumber = txtnumber.getText().toString().trim();
                Toast.makeText(TransfermoneyActivity.this, "You send an amount of " + amountsend + " to " + usernumber, Toast.LENGTH_SHORT).show();
                Intent backtoDashboard = new Intent(TransfermoneyActivity.this, MainActivity.class);
                startActivity(backtoDashboard);
            }

        });
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backtoDashboard = new Intent(TransfermoneyActivity.this, MainActivity.class);
                startActivity(backtoDashboard);
            }
        });
    }
}